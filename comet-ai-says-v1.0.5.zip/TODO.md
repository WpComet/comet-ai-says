[…] Easily - remove generated-saved ai desc.
[ ] Detailed error reports on fail - token fail or RPM or sth else
[ ] Non-factor text bug: regenerate on return
[ ] UI improv for admin list table 
- - Lightbox edit img maybe for seperate btn
- - Attach prod img to ai desc
- - Block UI, more clarity
[ ] Dashboard to move usage tracker to, and add other summaries
[?] Add Deepseek ? Offers free tier but requires account funding
[ ] Try more hooks to attach to product page
[ ] More admin filters; by price, asc-desc, rand etc.
[ ] Operation -admin- params; batch size etc.
[ ] Frontend button to regen if admin | shop manager
[ ] Rate limiting - precautionary or otherwise, IP, key limit etc.
[ ] Revise readme, screenshots, tags, description etc. for the plugin



<!--
===== Legend ====
[✔]         Done
[…]         In progress
[ ]         Undecided
- -         Depth
[?]         Considering
[x]         Scrapped
 -->